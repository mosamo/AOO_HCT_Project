package com.interfaces;

public interface IMedicinal {

    abstract public boolean isEdible();
    // all flowers in this database are edible but there are other..
    // ..non-edible objects that we can give the medicinal interface in the future (thinking with reusable design)

    abstract public String getUsageInstructions();
    // It is important to read usage instructions before consuming things with medicinal properties

    abstract public String getUsageWarning();
    // It is important to read warnings for things with medicinal property
}
