package com.interfaces;

// Aromatic definition: having a pleasant and distinctive smell.
public interface IAromatic {

    // Aroma Strength Classification
    public static final String CLASS_I = "Intense";
    public static final String CLASS_II = "Strong";
    public static final String CLASS_III = "Noticeable";
    public static final String CLASS_IV = "Slight";
    // (caps and underscore should be used for constants/final)

    abstract public String getScentClassification();
    abstract public String getScentDescription();
}
