package com.company;

import com.GUI.*;

import java.sql.SQLException;

public class Main {

    public static void main(String[] args) throws SQLException {
        JMFrame frame = new JMFrame("App", null);
    }
}
