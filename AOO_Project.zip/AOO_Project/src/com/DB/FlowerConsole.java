//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.DB;

import java.sql.SQLException;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

public class FlowerConsole {
    static Scanner scanner;
    static FlowerDAO flowerDAO;

    public FlowerConsole() {
    }

    public static void mmain2(String[] args) throws SQLException {
        for(String choice = ""; !choice.equals("7"); System.out.println("")) {
            System.out.print("Flower Database System\n========================\n1. Add a new flower\n2. Delete flower\n3. Update flower\n4. Find flower by ID\n5. Find flower by Type\n6. Show All Flowers\n7. Exit\nEnter your choice:");
            choice = scanner.nextLine();
            byte var3 = -1;
            switch(choice.hashCode()) {
            case 49:
                if (choice.equals("1")) {
                    var3 = 0;
                }
                break;
            case 50:
                if (choice.equals("2")) {
                    var3 = 1;
                }
                break;
            case 51:
                if (choice.equals("3")) {
                    var3 = 2;
                }
                break;
            case 52:
                if (choice.equals("4")) {
                    var3 = 3;
                }
                break;
            case 53:
                if (choice.equals("5")) {
                    var3 = 4;
                }
                break;
            case 54:
                if (choice.equals("6")) {
                    var3 = 5;
                }
                break;
            case 55:
                if (choice.equals("7")) {
                    var3 = 6;
                }
            }

            switch(var3) {
            case 0:
                doAddNewFlower();
                break;
            case 1:
                doDeleteFlower();
                break;
            case 2:
                doUpdateFlower();
                break;
            case 3:
                dogetFlowerById();
                break;
            case 4:
                doFindFlowerByType();
                break;
            case 5:
                doShowAllFlowers();
                break;
            case 6:
                System.exit(0);
                break;
            default:
                System.out.println("Enter a choice between 1 to 7!");
            }
        }

    }

    public static void dogetFlowerById() throws SQLException {
        System.out.println("");
        System.out.print("Enter flower to find (ID):");
        String id = scanner.nextLine();
        Flower flower = flowerDAO.getFlowerById(id);
        if (flower != null) {
            System.out.println(flower);
        } else {
            System.out.println("No flower with ID:" + id);
        }

    }

    public static void doFindFlowerByType() throws SQLException {
        System.out.println("Enter flower type to find (Malvoideae, Jasminaceae, Lilioideae, Magnoliaceae, Helianthus):");
        String type = scanner.nextLine();
        Flower flower = flowerDAO.getFlowerById(type);
        if (flower != null) {
            System.out.println(flower);
        } else {
            System.out.println("No flower with this type:" + type);
        }

    }

    public static void doAddNewFlower() throws SQLException {
        System.out.println("");
        System.out.print("Enter flower ID: ");
        String id = scanner.nextLine();
        System.out.print("Enter flower name: ");
        String name = scanner.nextLine();
        System.out.print("Enter latin family name (Malvoideae, Jasminaceae, Lilioideae, Magnoliaceae, Helianthus): ");
        String family = scanner.nextLine();
        System.out.print("Enter flower origin: ");
        String origin = scanner.nextLine();
        System.out.print("Enter the price: ");
        double price = scanner.nextDouble();
        System.out.print("Enter the quantity: ");
        int quantity = scanner.nextInt();
        int addStatus = flowerDAO.addNewFlower(id, name, family, origin, price, quantity);
        if (addStatus == 1) {
            System.out.println(id + " " + name + " Added successfully");
        } else {
            System.out.println("Error adding new flower " + id + " " + name);
        }

    }

    public static void doUpdateFlower() throws SQLException {
        System.out.println("");
        System.out.print("Enter flower ID to update:");
        String id = scanner.nextLine();
        if (flowerDAO.getFlowerById(id) == null) {
            System.out.println("No flower with id:" + id);
        } else {
            System.out.print("Enter new flower name: ");
            String name = scanner.nextLine();
            System.out.print("Enter new latin family name: ");
            String family = scanner.nextLine();
            System.out.print("Enter new flower origin: ");
            String origin = scanner.nextLine();
            System.out.print("Enter new the price: ");
            double price = scanner.nextDouble();
            System.out.print("Enter new the quantity: ");
            int quantity = scanner.nextInt();
            int updateStatus = flowerDAO.updateFlower(id, name, family, origin, price, quantity);
            if (updateStatus == 1) {
                System.out.println(id + " " + name + " updated successfully");
            } else {
                System.out.println("Error updating " + id + " " + name);
            }

        }
    }

    public static void doDeleteFlower() throws SQLException {
        System.out.println("");
        System.out.print("Enter flower ID to delete:");
        String id = scanner.nextLine();
        if (flowerDAO.getFlowerById(id) == null) {
            System.out.println("No flower with id:" + id);
        } else {
            int delStatus = flowerDAO.deleteFlower(id);
            if (delStatus == 2) {
                System.out.println(id + " deleted successfully");
            } else {
                System.out.println("Error deleting flower " + id);
            }

        }
    }

    public static void doShowAllFlowers() throws SQLException {
        List<Flower> flowerList = flowerDAO.getAllFlowers();
        System.out.println("");
        Iterator var1 = flowerList.iterator();

        while(var1.hasNext()) {
            Flower flower = (Flower)var1.next();
            System.out.println(flower);
        }

    }

    static {
        scanner = new Scanner(System.in);
        flowerDAO = new FlowerDAO();
    }
}
