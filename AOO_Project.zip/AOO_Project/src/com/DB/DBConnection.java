//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.DB;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {
    public DBConnection() {
    }

    public static Connection getConnection() throws SQLException {
        String dbURL = "jdbc:sqlite:flowerinfo.db";
        Connection conn = DriverManager.getConnection(dbURL);
        return conn;
    }
}
