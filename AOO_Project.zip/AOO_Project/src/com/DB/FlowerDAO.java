
//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.DB;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class FlowerDAO {
    public FlowerDAO() {
    }

    public static Flower getFlowerById(String id) throws SQLException {
        Connection conn = DBConnection.getConnection();
        Statement stmt = conn.createStatement();
        String querySQL = "SELECT * FROM FLOWER WHERE Id='" + id + "'";
        ResultSet rs = stmt.executeQuery(querySQL);
        Flower flower = null;
        if (rs.next()) {
            String name = rs.getString("NAME");
            String latinFamilyName = rs.getString("LATIN_FAMILY_NAME");
            String origin = rs.getString("ORIGIN");
            double price = rs.getDouble("PRICE");
            int quantity = rs.getInt("QUANTITY");
            flower = new Flower(id, name, latinFamilyName, origin, price, quantity);
        }

        stmt.close();
        rs.close();
        conn.close();
        return flower;
    }

    public static int addNewFlower(String id, String name, String latinFamilyName, String origin, double price, int quantity) throws SQLException {
        Connection conn = DBConnection.getConnection();
        String insertSQL = "INSERT INTO FLOWER VALUES('" + id + "','" + name + "','" + latinFamilyName + "','" + origin + "'," + price + "," + quantity + ");";
        Statement stmt = conn.createStatement();
        int insertStatus = stmt.executeUpdate(insertSQL);
        stmt.close();
        conn.close();
        return insertStatus;
    }

    public int updateFlower(String id, String name, String latinFamilyName, String origin, double price, int quantity) throws SQLException {
        Connection conn = DBConnection.getConnection();
        String updateSQL = "UPDATE FLOWER SET name ='" + name + "',latin_Family_Name = '" + latinFamilyName + "',origin=" + origin + "',price=" + price + "',quantity=" + quantity + " WHERE id='" + id + "';";
        System.out.println(updateSQL);
        Statement stmt = conn.createStatement();
        int updateStatus = stmt.executeUpdate(updateSQL);
        stmt.close();
        conn.close();
        return updateStatus;
    }

    public static int changeFlowerQuantity(String id, int quantity) throws SQLException {
        Connection conn = DBConnection.getConnection();
        String updateSQL = "UPDATE FLOWER SET quantity= " + quantity + " WHERE id='" + id + "'";
        Statement stmt = conn.createStatement();
        int updateStatus = stmt.executeUpdate(updateSQL);
        stmt.close();
        conn.close();
        return updateStatus;
    }

    public static int deleteFlower(String id) throws SQLException {
        Connection conn = DBConnection.getConnection();
        String deleteSQL = "DELETE FROM FLOWER WHERE id=?;";
        PreparedStatement pstmt = conn.prepareStatement(deleteSQL);
        pstmt.setString(1, id);
        int deleteStatus = pstmt.executeUpdate();
        pstmt.close();
        conn.close();
        return deleteStatus;
    }

    public static List<Flower> getAllFlowers() throws SQLException {
        String sql = "SELECT * FROM FLOWER";
        Connection conn = DBConnection.getConnection();
        Statement stmt = conn.createStatement();
        ResultSet rs = stmt.executeQuery(sql);
        ArrayList flowerList = new ArrayList();

        while(rs.next()) {
            String id = rs.getString("ID");
            String name = rs.getString("NAME");
            String latinFamilyName = rs.getString("LATIN_FAMILY_NAME");
            String origin = rs.getString("ORIGIN");
            double price = rs.getDouble("PRICE");
            int quantity = rs.getInt("QUANTITY");
            Flower flower = new Flower(id, name, latinFamilyName, origin, price, quantity);
            flowerList.add(flower);
        }

        rs.close();
        stmt.close();
        conn.close();
        return flowerList;
    }

    public static List<Flower> getFlowersByType(String latinFamilyName) throws SQLException {
        Connection conn = DBConnection.getConnection();
        Statement stmt = conn.createStatement();
        String querySQL = "SELECT * FROM FLOWER WHERE latin_Family_Name='" + latinFamilyName + "';";
        ResultSet rs = stmt.executeQuery(querySQL);
        ArrayList flowerList = new ArrayList();
        while (rs.next()) {
            String id = rs.getString("ID");
            String name = rs.getString("NAME");
            String origin = rs.getString("ORIGIN");
            double price = rs.getDouble("PRICE");
            int quantity = rs.getInt("QUANTITY");
            Flower flower = new Flower(id, name, latinFamilyName, origin, price, quantity);
            flowerList.add(flower);
        }

        stmt.close();
        rs.close();
        conn.close();
        return flowerList;
    }

    public static List<Flower> getFlowersLikeName(String fname) throws SQLException {
        Connection conn = DBConnection.getConnection();
        Statement stmt = conn.createStatement();
        String querySQL = "SELECT * FROM FLOWER WHERE NAME LIKE '%" + fname + "%';";
        ResultSet rs = stmt.executeQuery(querySQL);
        ArrayList flowerList = new ArrayList();
        while (rs.next()) {
            String id = rs.getString("ID");
            String origin = rs.getString("ORIGIN");
            double price = rs.getDouble("PRICE");
            int quantity = rs.getInt("QUANTITY");
            String name = rs.getString("NAME");
            String latinFamilyName = rs.getString("LATIN_FAMILY_NAME");
            Flower flower = new Flower(id, name, latinFamilyName, origin, price, quantity);
            flowerList.add(flower);
        }

        stmt.close();
        rs.close();
        conn.close();
        return flowerList;
    }
}

