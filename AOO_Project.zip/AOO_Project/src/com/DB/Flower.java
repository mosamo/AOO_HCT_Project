//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.DB;

public class Flower {
    private String id;
    private String name;
    private String latinFamilyName;
    private String origin;
    private double price;
    private int quantity;

    public Flower() {
    }

    public Flower(String id, String name, String latinFamilyName, String origin, double price, int quantity) {
        this.id = id;
        this.name = name;
        this.latinFamilyName = latinFamilyName;
        this.origin = origin;
        this.price = price;
        this.quantity = quantity;
    }

    public String getId() {
        return this.id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLatinFamilyName() {
        return this.latinFamilyName;
    }

    public void setLatinFamilyName(String latinFamilyName) {
        this.latinFamilyName = latinFamilyName;
    }

    public String getOrigin() {
        return this.origin;
    }

    public void setOrigin(String origin) {
        this.origin = origin;
    }

    public double getPrice() {
        return this.price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public int getQuantity() {
        return this.quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public String toString() {
        return "Flower{id=" + this.id + ", name=" + this.name + ", latinFamilyName=" + this.latinFamilyName + ", origin=" + this.origin + ", price=" + this.price + ", quantity=" + this.quantity + "}";
    }
}
