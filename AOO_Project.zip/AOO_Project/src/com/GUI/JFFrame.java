package com.GUI;

import com.DB.FlowerDAO;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.sql.SQLException;

// INSERT FLOWERS PAGE

public class JFFrame extends JFrame implements ActionListener {

    final Label label = new Label("((❀ ✿❀ Happy Flower Shop ❀✿ ❀))", Label.CENTER);
    final Label results = new Label("", Label.CENTER);
    final Font HEADER = new Font("Arial", Font.BOLD, 20);
    final Font BOLD_NORMAL_FONT = new Font("Arial", Font.BOLD, 16);
    final Font NORMAL_FONT = new Font("Arial", Font.PLAIN, 18);
    final Font INPUT_FONT = new Font("Arial", Font.PLAIN, 16);
    final Font BUTTON_FONT = new Font("Arial", Font.BOLD, 18);
    JTextField id_txt = new JTextField();
    JTextField name_txt = new JTextField();
    JTextField price_txt = new JTextField();
    JTextField origin_txt = new JTextField();
    ButtonGroup radioGroup = new ButtonGroup();
    JRadioButton r1 = new JRadioButton("Lily");
    JRadioButton r2 = new JRadioButton("Hibiscus");
    JRadioButton r3 = new JRadioButton("Jasmine");
    JRadioButton r4 = new JRadioButton("Magnolia");
    JRadioButton r5 = new JRadioButton("Sunflower");

    final int WIDTH = 800;
    final int HEIGHT = 600;
    final boolean RESIZABLE = false;
    final GroupLayout LAYOUT = new GroupLayout(this.getContentPane());

    public JFFrame(String title, Rectangle bounds) {
        super(title);
        setSize(WIDTH, HEIGHT);
        setLayout(LAYOUT);
        setBounds(bounds);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setDefaultLookAndFeelDecorated(false);
        setResizable(RESIZABLE);

        initalize();

        setVisible(true);
    }

    private void initalize() {
        Label topLabel = new Label("Insert Flowers to the Database:", Label.CENTER);
        topLabel.setFont(BOLD_NORMAL_FONT);

        r1.setFont(BOLD_NORMAL_FONT); radioGroup.add(r1);
        r2.setFont(BOLD_NORMAL_FONT); radioGroup.add(r2);
        r3.setFont(BOLD_NORMAL_FONT); radioGroup.add(r3);
        r4.setFont(BOLD_NORMAL_FONT); radioGroup.add(r4);
        r5.setFont(BOLD_NORMAL_FONT); radioGroup.add(r5);
        id_txt.setFont(INPUT_FONT);
        name_txt.setFont(INPUT_FONT);
        price_txt.setFont(INPUT_FONT);
        origin_txt.setFont(INPUT_FONT);

        results.setFont(BUTTON_FONT);
        results.setForeground(Color.red);

        Label T1 = new Label("Enter Flower ID:", Label.CENTER); T1.setFont(NORMAL_FONT);
        Label T2 = new Label("Enter Flower Name:", Label.CENTER); T2.setFont(NORMAL_FONT);
        Label T3 = new Label("Choose Flower Type:", Label.CENTER); T3.setFont(NORMAL_FONT);
        Label T4 = new Label("Enter Flower Price:", Label.CENTER); T4.setFont(NORMAL_FONT);
        Label T5 = new Label("Enter Flower Origin:", Label.CENTER); T5.setFont(NORMAL_FONT);

        label.setFont(HEADER);
        JLabel logo = new JLabel("");
        JLabel logo_right = new JLabel("");
        logo.setIcon(new ImageIcon("src/resources/logo.png"));
        logo_right.setIcon(new ImageIcon("src/resources/ogol.png"));
        // //
        Button btn_back = new Button("Back");
        btn_back.addActionListener(this::actionPerformed);
        btn_back.setFont(BUTTON_FONT);
        Button btn_exit = new Button("Exit");
        btn_exit.setFont(BUTTON_FONT);
        btn_exit.addActionListener(this::actionPerformed);
        Button btn_submit = new Button("Submit");
        btn_submit.setFont(BUTTON_FONT);
        btn_submit.addActionListener(this::actionPerformed);

        LAYOUT.setAutoCreateContainerGaps(true);
        LAYOUT.setAutoCreateGaps(true);

        LAYOUT.setHorizontalGroup(
                LAYOUT.createParallelGroup(GroupLayout.Alignment.LEADING)
                        // header
                        .addGroup(LAYOUT.createSequentialGroup()
                                .addComponent(logo_right, 140, 140, 140)
                                .addGap(60, 60, 60)
                                .addComponent(label)
                                .addComponent(logo, 140, 140, 140)

                        )
                        // middle group
                        .addComponent(topLabel)

                        .addGroup(LAYOUT.createSequentialGroup()
                                .addGap( 230, 230, 230)
                                .addComponent(T1, 130, 130, 130)
                                .addComponent(id_txt, 50, 50, 50)
                        )

                        .addGroup(LAYOUT.createSequentialGroup()
                                .addGap( 200, 200, 200)
                                .addComponent(T2, 160, 160, 160)
                                .addComponent(name_txt, 200, 200, 200)
                        )
                        .addGroup(LAYOUT.createParallelGroup(GroupLayout.Alignment.CENTER)
                                .addComponent(T3)
                                .addGroup(LAYOUT.createSequentialGroup()
                                        .addComponent(r1)
                                        .addComponent(r2)
                                        .addComponent(r3)
                                        .addComponent(r4)
                                        .addComponent(r5)
                                )
                        )
                        .addGroup(LAYOUT.createSequentialGroup()
                                .addGap( 200, 200, 200)
                                .addComponent(T4, 160, 160, 160)
                                .addComponent(price_txt, 50, 50, 50)
                        )
                        .addGroup(LAYOUT.createSequentialGroup()
                                .addGap( 200, 200, 200)
                                .addComponent(T5, 160, 160, 160)
                                .addComponent(origin_txt, 200, 200, 200)
                        )
                        .addGroup(LAYOUT.createParallelGroup()
                                .addGroup(LAYOUT.createSequentialGroup()
                                        .addGap(40, 40, 40)
                                        .addComponent(results)
                                )
                        )
                        .addGroup(LAYOUT.createParallelGroup()
                                .addGroup(LAYOUT.createSequentialGroup()
                                        .addGap(250, 250, 250)
                                        .addComponent(btn_submit, 310, 310, 310)
                                )
                        )
                        // last group
                        .addGroup(LAYOUT.createParallelGroup()
                                .addGroup(LAYOUT.createSequentialGroup()
                                        .addGap(250, 250, 250)
                                        .addComponent(btn_back, 140, 140, 140)
                                        .addGap(30, 30, 30)
                                        .addComponent(btn_exit, 140, 140, 140)
                                )
                        )
        );
        // Rows
        LAYOUT.setVerticalGroup(
                LAYOUT.createSequentialGroup()
                        .addGroup(LAYOUT.createParallelGroup()
                                .addComponent(logo, 40, 40, 40)
                                .addComponent(label, 40, 40, 40)
                                .addComponent(logo_right, 40, 40, 40)
                        )
                        .addComponent(topLabel, 50, 50, 50)
                        .addGroup(LAYOUT.createParallelGroup()
                                .addComponent(T1, 30, 30, 30)
                                .addComponent(id_txt, 30, 30, 30)
                        )
                        .addGroup(LAYOUT.createParallelGroup()
                                .addComponent(T2, 30, 30, 30)
                                .addComponent(name_txt, 30, 30, 30)
                        )
                        .addGroup(LAYOUT.createSequentialGroup()
                                .addGap(10, 10, 10)
                                .addComponent(T3, 30, 30, 30)
                                .addGroup(LAYOUT.createParallelGroup(GroupLayout.Alignment.CENTER)
                                        .addComponent(r1, 30, 30, 30)
                                        .addComponent(r2, 30, 30, 30)
                                        .addComponent(r3, 30, 30, 30)
                                        .addComponent(r4, 30, 30, 30)
                                        .addComponent(r5, 30, 30, 30)
                                )

                        )

                        .addGroup(LAYOUT.createParallelGroup()
                                .addComponent(T4, 30, 30, 30)
                                .addComponent(price_txt, 30, 30, 30)
                        )

                        .addGroup(LAYOUT.createParallelGroup()
                                .addComponent(T5, 30, 30, 30)
                                .addComponent(origin_txt, 30, 30, 30)
                        )
                        .addGap(20, 20, 20)
                        .addComponent(results)
                        .addComponent(btn_submit, 40, 40, 40)
                        .addGroup(LAYOUT.createParallelGroup()
                                .addComponent(btn_back, 60, 60, 60)
                                .addComponent(btn_exit,60, 60, 60)
                        )


        );
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        Object source = e.getSource();
        if (source instanceof Button) {
            String label = ((Button) source).getLabel();
            switch (label) {
                case "Exit":
                    this.dispatchEvent(new WindowEvent(this, WindowEvent.WINDOW_CLOSING));
                    break;
                case "Back":
                    this.setVisible(false);
                    JMFrame frameM = new JMFrame("App", this.getBounds());
                    break;
                case "Submit":
                    if (id_txt.getText().equals("") ||
                        name_txt.getText().equals("") ||
                        price_txt.getText().equals("") ||
                        origin_txt.getText().equals("") ||
                          radioGroup.getSelection() == null
                        ) {
                        results.setText("Some fields missing");
                    } else {
                        double price;
                        try {
                            price = Double.parseDouble(price_txt.getText());
                            FlowerDAO.addNewFlower(id_txt.getText(), name_txt.getText(), getScientificRegularName(true), origin_txt.getText(), price, 20);
                            results.setText("Added " + name_txt.getText() +" Flower Successfully");
                        } catch (NumberFormatException nfe) {
                            results.setText("Price is incorrect format");
                            return;
                        } catch (SQLException sqle) {
                            results.setText(sqle.getMessage());
                        }
                    }

                    break;
                default:
                    break;
            }
        }
    }

    private String getScientificRegularName(boolean scientific) {
        // we have to create a custom method because the labels use the normal name
        //                                and the database uses the scientific name
        // Lily -> Lilioideae


        // SCIENTIFIC NAMES
        if (scientific) {
            if (r1.isSelected()) {
                return "Lilioideae";
            } else if (r2.isSelected()) {
                return "Malvoideae";
            } else if (r3.isSelected()) {
                return "Jasminaceae";
            } else if (r4.isSelected()) {
                return "Magnoliaceae";
            } else if (r5.isSelected()) {
                return "Helianthus";
            }
        } else {
            // REGULAR NAMES
            if (r1.isSelected()) {
                return "Lily";
            } else if (r2.isSelected()) {
                return "Hibiscus";
            } else if (r3.isSelected()) {
                return "Jasmine";
            } else if (r4.isSelected()) {
                return "Magnolia";
            } else if (r5.isSelected()) {
                return "Sunflower";
            }
        }
        return "none";
    }

}
