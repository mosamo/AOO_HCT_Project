package com.GUI;

import com.DB.Flower;
import com.DB.FlowerDAO;
import com.sales.FlowerFactory;
import com.sales.Bouquet;
import com.sales.Cart;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

// MAIN PAGE OF THE APPLICATION

public class JMFrame extends JFrame implements ActionListener {
    final int WIDTH = 800;
    final int HEIGHT = 600;
    final boolean RESIZABLE = false;

    JList list = new JList();

    JCheckBox checkBox = new JCheckBox("Wrap in Bouquet? (+25 AED)");
    JTextField txt_qty = new JTextField();
    JTextField txt_id = new JTextField();
    JTextField txt_name = new JTextField();
    ButtonGroup radioGroup = new ButtonGroup();
    JRadioButton r1 = new JRadioButton("Lily");
    JRadioButton r2 = new JRadioButton("Hibiscus");
    JRadioButton r3 = new JRadioButton("Jasmine");
    JRadioButton r4 = new JRadioButton("Magnolia");
    JRadioButton r5 = new JRadioButton("Sunflower");
    List<Flower> flowers = Collections.<Flower>emptyList();
    Label T1 = new Label("Search by Flower ID: ");
    Label T2 = new Label("Search by Flower Name: ");
    Label T3 = new Label("Search by Flower Type: ");

    final Font HEADER = new Font("Arial", Font.BOLD, 20);
    final Font BUTTON_FONT = new Font("Arial", Font.BOLD, 18);
    final Font INPUT_FONT = new Font("Arial", Font.PLAIN, 16);
    final Font BOLD_SMALL_INPUT = new Font("Arial", Font.BOLD, 14);
    final Font BOLD_NORMAL_FONT = new Font("Arial", Font.BOLD, 16);

    final GroupLayout LAYOUT = new GroupLayout(this.getContentPane());
    public JMFrame(String title, Rectangle location) {
        super(title);
        setSize(WIDTH, HEIGHT);
        setLayout(LAYOUT);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setDefaultLookAndFeelDecorated(false);
        setResizable(RESIZABLE);

        // this decides the location of this window
        // based on if it was called from another window (so it matches location as previous window)
        // but it is null when it is initially called
        if (location != null) {
            setBounds(location);
        }

        initialize();

        setVisible(true);
    }



    public void initialize () {
        Label label = new Label("((❀ ✿❀ Happy Flower Shop ❀✿ ❀))", Label.CENTER);
        label.setFont(HEADER);

        Button btn_BuyFlower = new Button("Buy Flowers");
        btn_BuyFlower.addActionListener(this::actionPerformed);
        btn_BuyFlower.setFont(BUTTON_FONT);
        btn_BuyFlower.setEnabled(false);

        Button btn_ViewCart = new Button("View Cart");
        btn_ViewCart.addActionListener(this::actionPerformed);
        btn_ViewCart.setFont(BUTTON_FONT);

        Button btn_AboutPage = new Button("About");
        btn_AboutPage.addActionListener(this::actionPerformed);
        btn_AboutPage.setFont(BUTTON_FONT);

        Button btn_addFlower = new Button("Insert Flowers");
        btn_addFlower.addActionListener(this::actionPerformed);
        btn_addFlower.setFont(BUTTON_FONT);

        Button btn_exitApp = new Button("Exit");
        btn_exitApp.addActionListener(this::actionPerformed);
        btn_exitApp.setFont(BUTTON_FONT);

        // display list is initialized on top
        list.setLayoutOrientation(JList.VERTICAL);
        JScrollPane scrollbar = new JScrollPane(list);
        scrollbar.setViewportView(list);
        // end of display list

        Button btn_searchQuery = new Button("Search");
        btn_searchQuery.addActionListener(this::actionPerformed);
        btn_searchQuery.setFont(BOLD_NORMAL_FONT);

        Button btn_allFlower = new Button("See All Flowers");
        btn_allFlower.addActionListener(this::actionPerformed);
        btn_allFlower.setFont(BOLD_NORMAL_FONT);

        Button btn_purchase = new Button("Add to Cart");
        btn_purchase.addActionListener(this::actionPerformed);
        btn_purchase.setFont(BOLD_SMALL_INPUT);

        r1.setFont(BOLD_NORMAL_FONT); radioGroup.add(r1); r1.addFocusListener(myFocusListener);
        r2.setFont(BOLD_NORMAL_FONT); radioGroup.add(r2); r2.addFocusListener(myFocusListener);
        r3.setFont(BOLD_NORMAL_FONT); radioGroup.add(r3); r3.addFocusListener(myFocusListener);
        r4.setFont(BOLD_NORMAL_FONT); radioGroup.add(r4); r4.addFocusListener(myFocusListener);
        r5.setFont(BOLD_NORMAL_FONT); radioGroup.add(r5); r5.addFocusListener(myFocusListener);

        txt_id.setFont(INPUT_FONT);
        txt_id.addKeyListener(myKeyListener);
        txt_id.setName("idfield");
        txt_name.setFont(INPUT_FONT);
        txt_name.addKeyListener(myKeyListener);
        txt_name.setName("namefield");
        txt_qty.setFont(INPUT_FONT);

        JLabel logo = new JLabel("");
        logo.setIcon(new ImageIcon("src/resources/logo.png"));
        JLabel logo_right = new JLabel("");
        logo_right.setIcon(new ImageIcon("src/resources/ogol.png"));

        Label T4 = new Label("Select Flowers ");
        Label T5 = new Label("Welcome to the flower shop!", Label.CENTER);
        T1.setFont(BUTTON_FONT);
        T2.setFont(BUTTON_FONT);
        T3.setFont(BUTTON_FONT);
        T4.setFont(BUTTON_FONT);
        T5.setFont(BOLD_NORMAL_FONT);

        LAYOUT.setAutoCreateContainerGaps(true);
        LAYOUT.setAutoCreateGaps(true);

        LAYOUT.setHorizontalGroup(
                LAYOUT.createParallelGroup(GroupLayout.Alignment.LEADING)
                        .addGroup(LAYOUT.createSequentialGroup()
                                .addComponent(logo, 140, 140, 140)
                                .addGap(60, 60, 60)
                                .addComponent(label)
                                .addComponent(logo_right, 140, 140, 140)
                        )
                        .addGroup(LAYOUT.createParallelGroup()
                                .addGroup(LAYOUT.createSequentialGroup()
                                        .addComponent(btn_BuyFlower, 220, 220, 220)
                                        .addGroup(LAYOUT.createParallelGroup()
                                                .addComponent(T1)
                                                .addComponent(txt_id)
                                        )
                                        .addComponent(T5)
                                )
                                .addGroup(LAYOUT.createSequentialGroup()
                                        .addComponent(btn_ViewCart, 220, 220, 220)
                                        .addGroup(LAYOUT.createParallelGroup()
                                                .addComponent(T2)
                                                .addComponent(txt_name)
                                        )
                                )
                                .addGroup(LAYOUT.createSequentialGroup()
                                        .addComponent(btn_AboutPage, 220, 220, 220)
                                        .addGroup(LAYOUT.createParallelGroup()
                                                .addComponent(T3)
                                                .addGroup(LAYOUT.createSequentialGroup()
                                                        .addComponent(r1)
                                                        .addComponent(r2)
                                                        .addComponent(r3)
                                                        .addComponent(r4)
                                                        .addComponent(r5)
                                                )
                                        )
                                )
                                .addGroup(LAYOUT.createSequentialGroup()
                                        .addComponent(btn_addFlower, 220, 220, 220)
                                                .addGroup(LAYOUT.createSequentialGroup()
                                                        .addGap(100, 100, 100)
                                                        .addComponent(btn_searchQuery, 200, 200, 200)
                                                        .addComponent(btn_allFlower, 200, 200, 200)
                                                )
                                )
                                .addGroup(LAYOUT.createSequentialGroup()
                                        .addComponent(btn_exitApp, 220, 220, 220)
                                        .addGroup(LAYOUT.createParallelGroup()
                                                .addComponent(T4)
                                                .addComponent(scrollbar, 340, 340, 340)
                                        )
                                        .addGroup(LAYOUT.createParallelGroup()
                                                .addGroup(LAYOUT.createSequentialGroup()
                                                        .addComponent(btn_purchase, 100, 100, 100)
                                                        .addComponent(txt_qty)
                                                )
                                                .addGroup(LAYOUT.createSequentialGroup()
                                                        .addComponent(checkBox)
                                                )
                                        )
                                )
                        )
        );
        // rows
        LAYOUT.setVerticalGroup(
                LAYOUT.createSequentialGroup()
                        .addGroup(LAYOUT.createParallelGroup(GroupLayout.Alignment.CENTER)
                                .addComponent(logo, 40, 40, 40)
                                .addComponent(label, 40, 40, 40)
                                .addComponent(logo_right, 40, 40, 40)
                        )
                        .addGroup(LAYOUT.createSequentialGroup()
                                .addGroup(LAYOUT.createParallelGroup()
                                        .addComponent(btn_BuyFlower)
                                        .addGroup(LAYOUT.createSequentialGroup()
                                                .addComponent(T1)
                                                .addComponent(txt_id)
                                        )
                                        .addComponent(T5)
                                )
                                .addGroup(LAYOUT.createParallelGroup()
                                        .addComponent(btn_ViewCart)
                                        .addGroup(LAYOUT.createSequentialGroup()
                                                .addComponent(T2)
                                                .addComponent(txt_name)
                                        )
                                )
                                .addGroup(LAYOUT.createParallelGroup()
                                        .addComponent(btn_AboutPage)
                                        .addGroup(LAYOUT.createSequentialGroup()
                                                .addComponent(T3)
                                                .addGroup(LAYOUT.createParallelGroup()
                                                        .addComponent(r1)
                                                        .addComponent(r2)
                                                        .addComponent(r3)
                                                        .addComponent(r4)
                                                        .addComponent(r5)
                                                )
                                        )
                                )

                                .addGroup(LAYOUT.createParallelGroup()
                                        .addComponent(btn_addFlower)
                                        .addComponent(btn_searchQuery)
                                        .addComponent(btn_allFlower)
                                )
                                .addGroup(LAYOUT.createParallelGroup()
                                        .addComponent(btn_exitApp, 130, 130, 130)
                                        .addGroup(LAYOUT.createSequentialGroup()
                                                .addGap(10, 10, 10)
                                                .addComponent(T4, 30, 30, 30)
                                                .addComponent(scrollbar, 80, 80, 80)
                                        )
                                        .addGroup(LAYOUT.createSequentialGroup()
                                                .addGap(40, 40, 40)
                                                .addGroup(LAYOUT.createParallelGroup()
                                                        .addComponent(btn_purchase, 30, 30, 30)
                                                        .addComponent(txt_qty, 30, 30, 30)
                                                )
                                                .addGroup(LAYOUT.createParallelGroup()
                                                        .addComponent(checkBox)
                                                )
                                        )
                                )

                                .addGap(20, 20, 20)
                        )
        );
    }

    private void ListAllFlowers() {

        clearLists();
        list.setEnabled(true);

        try {
            flowers = FlowerDAO.getAllFlowers();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        writeInDisplayList(flowers);

        enableSearchComponents();
    }

    private void writeInDisplayList(List<Flower> flist) {
        List strings = new ArrayList();
        // ADD THESE TO QUERY METHODS ALSO


        for (Flower f : flist) {
            strings.add(f.getId() + " - " + f.getName() + " - " + f.getPrice() + " AED - Qty: " + f.getQuantity());

        }

        String [] listdata = new String[strings.size()];
        strings.toArray(listdata);
        list.setListData(listdata);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        Object source = e.getSource();
        if (source instanceof Button) {
            String label = ((Button) source).getLabel();
            switch (label) {
                case "Exit":
                    this.dispatchEvent(new WindowEvent(this, WindowEvent.WINDOW_CLOSING));
                    break;
                case "See All Flowers":
                    list.setListData(new String[] {"Loading.."});
                    ListAllFlowers();
                    clearInputs();
                    break;
                case "Search":
                    // if everything is enabled then there is no specific, get all entries
                    if (txt_name.isEnabled() == true && txt_id.isEnabled() == true && r1.isEnabled() == true) {
                        list.setListData(new String[]{"Loading.."});
                        ListAllFlowers();
                        clearInputs();
                    } else if (txt_name.isEnabled()) {
                        // search by name
                        clearLists();
                        list.setEnabled(true);
                        try {
                            flowers = FlowerDAO.getFlowersLikeName(txt_name.getText());
                            writeInDisplayList(flowers);
                        } catch (SQLException sqle) {
                            sqle.printStackTrace();
                        } catch (NullPointerException npex) {
                            list.setEnabled(false);
                            list.setListData(new String[] {"No Entry Found for Name: " + txt_name.getText()});
                        }

                    } else if (txt_id.isEnabled()) {
                        // search by id
                        clearLists();
                        list.setEnabled(true);
                        try {
                            List<Flower> acquired = new ArrayList<>();
                            acquired.add(FlowerDAO.getFlowerById(txt_id.getText().toUpperCase()));
                            flowers = acquired;
                            // write to list
                            writeInDisplayList(flowers);
                        } catch (SQLException sqle) {
                            sqle.printStackTrace();
                        } catch (NullPointerException npex) {
                            list.setEnabled(false);
                            list.setListData(new String[] {"No Entry Found for id: " + txt_id.getText().toUpperCase()});
                        }

                    } else if (r1.isEnabled()) {
                        // search by type
                        clearLists();
                        list.setEnabled(true);
                        // see method for reason why we used it
                        try {
                            flowers = FlowerDAO.getFlowersByType(getScientificRegularName(true));
                            writeInDisplayList(flowers);
                        } catch (SQLException sqle) {
                            sqle.printStackTrace();
                        } catch (NullPointerException npex) {
                            list.setEnabled(false);
                            list.setListData(new String[] {"No Entry Found for Type: " + getScientificRegularName(false)});
                        }
                    }
                    break;
                case "Add to Cart":
                    try {
                        // check if textbox is null
                        if (!txt_qty.getText().equalsIgnoreCase("")) {
                            Cart cart = Cart.getInstance();

                            // handle number format exception
                            int neededqty;
                            try {
                                neededqty = Integer.parseInt(txt_qty.getText());
                            } catch (NumberFormatException nfe) {
                                txt_qty.setText("");
                                break;
                            }
                            if (flowers == null) {
                                txt_qty.setText("");
                                ListAllFlowers();
                                list.setEnabled(false);
                                list.setListData(new String[] {"Search flowers first!"});
                                break;
                            }
                            // get flower from flower list
                            Flower selection = flowers.get(list.getSelectedIndex());
                            int remainder = selection.getQuantity() - neededqty;
                            if (remainder > -1) {
                                try {
                                    int success = FlowerDAO.changeFlowerQuantity(selection.getId(), remainder);
                                    Flower newFlowerAdded = new Flower(selection.getId(), selection.getName(), selection.getLatinFamilyName(), selection.getOrigin(), selection.getPrice(), neededqty);

                                    // if this flower ran out, DELETE IT FROM THE DATABASE
                                    if (remainder == 0) {
                                        int deletionSuccess = FlowerDAO.deleteFlower(selection.getId());
                                    }

                                    // if user doesnt want bouquet:
                                    if (!checkBox.isSelected()) {
                                        cart.add(newFlowerAdded);

                                        ListAllFlowers();
                                        list.setListData(new String[]{"Added " + neededqty + " " + selection.getName() + " to cart!"});

                                    } else {
                                        // bouqout<T> creates a flower of the correct type using flower factory
                                        cart.add(new Bouquet(FlowerFactory.createFlowerByType(selection.getLatinFamilyName(), selection.getId(), selection.getName(), selection.getOrigin(), selection.getPrice(), neededqty)));

                                        ListAllFlowers();
                                        list.setListData(new String[]{"Added a Bouquet of " + neededqty + " " + selection.getName() + " to cart!"});

                                    }
                                    list.setEnabled(false);
                                    clearInputs();

                                } catch (SQLException ex) {
                                    ex.printStackTrace();
                                }
                            } else {
                                ListAllFlowers();
                                list.setListData(new String[]{selection.getName() + ": Quantity not available"});
                                list.setEnabled(false);
                                clearInputs();
                            }

                        }
                    } catch (ArrayIndexOutOfBoundsException exception) {
                        list.setListData(new String[] {"No Item Selected"});
                        list.setEnabled(false);
                        txt_qty.setText("");
                    }
                    break;
                case "About":
                    // TODO: shoul v be f?
                    this.setVisible(false);
                    JAFrame frameA = new JAFrame("App", this.getBounds());
                    break;
                case "Insert Flowers":
                    this.setVisible(false);
                    JFFrame frameF = new JFFrame("App", this.getBounds());
                    break;
                case "View Cart":
                    this.setVisible(false);
                    ViewCart.mmain(this.getBounds());
                    break;
                default:
                    System.out.println(label);
                    break;
            }
        }
    }

    private String getScientificRegularName(boolean scientific) {
        // we have to create a custom method because the labels use the normal name
        //                                and the database uses the scientific name
        // Lily -> Lilioideae


        // SCIENTIFIC NAMES
        if (scientific) {
            if (r1.isSelected()) {
                return "Lilioideae";
            } else if (r2.isSelected()) {
                return "Malvoideae";
            } else if (r3.isSelected()) {
                return "Jasminaceae";
            } else if (r4.isSelected()) {
                return "Magnoliaceae";
            } else if (r5.isSelected()) {
                return "Helianthus";
            }
        } else {
            // REGULAR NAMES
            if (r1.isSelected()) {
                return "Lily";
            } else if (r2.isSelected()) {
                return "Hibiscus";
            } else if (r3.isSelected()) {
                return "Jasmine";
            } else if (r4.isSelected()) {
                return "Magnolia";
            } else if (r5.isSelected()) {
                return "Sunflower";
            }
        }
        return "none";
    }



    private void clearLists() {
        try {
            flowers.clear();
        } catch (NullPointerException exception) {
            // null pointer exception can happen if you try to clear a null list
        }
    }

    FocusListener myFocusListener = new FocusListener() {
        @Override
        public void focusGained(FocusEvent e) {
            if (e.getSource() instanceof JRadioButton) {
                txt_name.setEnabled(false);
                txt_id.setEnabled(false);
                T1.setForeground(Color.GRAY);
                T2.setForeground(Color.GRAY);
            }
        }

        @Override
        public void focusLost(FocusEvent e) {
        }
    };

    KeyListener myKeyListener = new KeyListener() {
        @Override
        public void keyTyped(KeyEvent e) {

        }

        @Override
        public void keyPressed(KeyEvent e) {

        }

        @Override
        public void keyReleased(KeyEvent e) {
            Object source = e.getSource();
            if (source instanceof JTextField) {
                JTextField component = ((JTextField) source);
                switch (component.getName()) {
                    case "idfield":
                        txt_name.setEnabled(false);
                        radioGroup.clearSelection();
                        setEnableRadioGroup(false);
                        T2.setForeground(Color.GRAY);
                        T3.setForeground(Color.GRAY);
                        break;
                    case "namefield":
                        txt_id.setEnabled(false);
                        radioGroup.clearSelection();
                        setEnableRadioGroup(false);
                        T1.setForeground(Color.GRAY);
                        T3.setForeground(Color.GRAY);
                        break;
                }
                // if everything is empty then he can choose to change his query
                if (component.getText().equals("")) {
                    enableSearchComponents();
                }
            }
        }
    };

    private void enableSearchComponents() {
        txt_name.setEnabled(true);
        txt_id.setEnabled(true);
        setEnableRadioGroup(true);
        T1.setForeground(Color.BLACK);
        T2.setForeground(Color.BLACK);
        T3.setForeground(Color.BLACK);
    }

    private void setEnableRadioGroup(boolean b) {
        r1.setEnabled(b);
        r2.setEnabled(b);
        r3.setEnabled(b);
        r4.setEnabled(b);
        r5.setEnabled(b);
    }

    private void clearInputs() {
        txt_name.setText("");
        txt_id.setText("");
        txt_qty.setText("");
        radioGroup.clearSelection();
    }
}