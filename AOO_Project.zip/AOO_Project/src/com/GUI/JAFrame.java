package com.GUI;

import com.DB.Flower;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.util.Collections;
import java.util.List;

// ABOUT PAGE

public class JAFrame extends JFrame implements ActionListener {

    final Label label = new Label("((❀ ✿❀ Happy Flower Shop ❀✿ ❀))", Label.CENTER);
    final Font HEADER = new Font("Arial", Font.BOLD, 20);
    final Font BOLD_NORMAL_FONT = new Font("Arial", Font.BOLD, 16);
    final Font BUTTON_FONT = new Font("Arial", Font.BOLD, 18);
    final int WIDTH = 800;
    final int HEIGHT = 600;
    final boolean RESIZABLE = false;
    final GroupLayout LAYOUT = new GroupLayout(this.getContentPane());

    public JAFrame(String title, Rectangle bounds) {
        super(title);
        setSize(WIDTH, HEIGHT);
        setLayout(LAYOUT);
        setBounds(bounds);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setDefaultLookAndFeelDecorated(false);
        setResizable(RESIZABLE);

        initalize();

        setVisible(true);
    }

    private void initalize() {
        JLabel main = new JLabel(text);
        label.setFont(HEADER);
        JLabel logo = new JLabel("");
        JLabel logo_right = new JLabel("");
        logo.setIcon(new ImageIcon("src/resources/logo.png"));
        logo_right.setIcon(new ImageIcon("src/resources/ogol.png"));
        //
        main.setFont(BOLD_NORMAL_FONT);
        Button btn_back = new Button("Back");
        btn_back.addActionListener(this::actionPerformed);
        btn_back.setFont(BUTTON_FONT);
        Button btn_exit = new Button("Exit");
        btn_exit.setFont(BUTTON_FONT);
        btn_exit.addActionListener(this::actionPerformed);


        LAYOUT.setAutoCreateContainerGaps(true);
        LAYOUT.setAutoCreateGaps(true);

        // Columns
        LAYOUT.setHorizontalGroup(
                LAYOUT.createParallelGroup()
                        .addGroup(LAYOUT.createSequentialGroup()
                                .addComponent(logo_right, 140, 140, 140)
                                .addGap(60, 60, 60)
                                .addComponent(label)
                                .addComponent(logo, 140, 140, 140)

                        )
                        .addGroup(LAYOUT.createSequentialGroup()

                                .addGap(250, 250, 250)
                                .addComponent(main, 500, 500, 500)

                        )
                        .addGroup(LAYOUT.createParallelGroup()
                                .addGroup(LAYOUT.createSequentialGroup()
                                        .addGap(250, 250, 250)
                                        .addComponent(btn_back, 140, 140, 140)
                                        .addGap(30, 30, 30)
                                        .addComponent(btn_exit, 140, 140, 140)
                                )
                        )
        );
        // Rows
        LAYOUT.setVerticalGroup(
                LAYOUT.createSequentialGroup()
                        .addGroup(LAYOUT.createParallelGroup()
                                .addComponent(logo, 40, 40, 40)
                                .addComponent(label, 40, 40, 40)
                                .addComponent(logo_right, 40, 40, 40)
                        )
                        .addGroup(LAYOUT.createSequentialGroup()
                                .addGap(50, 50, 50)
                                .addComponent(main)
                                .addGap(20, 20, 20)
                                .addGroup(LAYOUT.createParallelGroup()
                                        .addComponent(btn_back, 60, 60, 60)
                                        .addComponent(btn_exit,60, 60, 60)
                                )
                        )

        );
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        Object source = e.getSource();
        if (source instanceof Button) {
            String label = ((Button) source).getLabel();
            switch (label) {
                case "Exit":
                    this.dispatchEvent(new WindowEvent(this, WindowEvent.WINDOW_CLOSING));
                    break;
                case "Back":
                    this.setVisible(false);
                    JMFrame frameM = new JMFrame("App", this.getBounds());
                    break;
                default:
                    break;
            }
        }
    }

    // I'm putting the text here so it doesn't disturb reading the code
    // JLabel takes html and not \n
    final String text =
            "<html><center>About:<br><br>" +
            "Welcome to Flower Shop Application,<br>" +
            "In this application you can:<ul><li>Search Flowers By ID</li>" +
            "<li>Search Flowers By Name</li>" +
            "<li>Search Flowers By Type</li>" +
            "<li>Select and Buy Flowers</li>" +
            "<li>Buy Bouquets of Flowers</li>" +
            "<li>Insert Flowers into Shop</li></ul>" +
            "<hr>" +
            "<br>Group Project By:<br><br>" +
            "Mohamed Mosabeh Alremeithi (H00374092)<br>" +
            "Mohammed Khalid Alzaabi (H00385075)<br>" +
            "Ibrahim Ahmed Alhammadi (H00370619)<br>" +
            "Eidha Abdulla Albreiki (H00323442)<br>" +
            "</center></html>";
}
