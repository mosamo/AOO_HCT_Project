package com.flowers;

import com.interfaces.IMedicinal;
import com.interfaces.IAromatic;

public class Magnolia extends Flower implements IMedicinal, IAromatic {

    private boolean crownedCarpel;
    private boolean pinkTint;

    public Magnolia(String id, String name, String origin, double price,int qty, boolean crownedCarpel, boolean pinkTint) {
        super(id, name, origin, price, qty);

        setCrownedCarpel(crownedCarpel);
        setPinkTint(pinkTint);

        setLatinFamilyName("Magnoliaceae");
    }

    public boolean hasCrownedCarpel() {
        return crownedCarpel;
    }

    public void setCrownedCarpel(boolean crownedCarpel) {
        this.crownedCarpel = crownedCarpel;
    }

    public boolean hasPinkTint() {
        return pinkTint;
    }

    public void setPinkTint(boolean pinkTint) {
        this.pinkTint = pinkTint;
    }

    @Override
    public boolean isEdible() { // acquired from the IMedicinal Interface
        // Magnolias are Edible
        return true;
    }

    @Override
    public String getUsageInstructions() { // acquired from the IMedicinal Interface
        return "Magnolia petals can be dried and boiled in tea, and can also be eaten raw," +
               " and are regularly consumed for their health benefits and soothing effects";

    }

    @Override
    public String getUsageWarning() { // acquired from the IMedicinal Interface
        return "Warning: Magnolias have high sedative properties, they cause sleepiness and slow breathing," +
                        "Magnolia consumption is not recommended for pregnant women";
    }

    @Override
    public String getScentClassification() { // acquired from the IAromatic Interface
        return IAromatic.CLASS_III;
    }

    @Override
    public String getScentDescription() { // acquired from the IAromatic Interface
        return getName() + " have a relaxing, floral smell\n" +
                "Scent Grade: " + getScentClassification();
    }
}
