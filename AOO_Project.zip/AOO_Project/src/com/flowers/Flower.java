package com.flowers;

public abstract class Flower {

    private String id;
    private String name;
    private String latinFamilyName;
    private String origin;
    private double price;

    private int qty;

    public Flower(String id, String name, String origin, double price, int qty) {
        this.id = id;
        this.name = name;
        this.origin = origin;
        this.price = price;
        this.qty = qty;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLatinFamilyName() {
        return latinFamilyName;
    }

    public void setLatinFamilyName(String latinFamilyName) {
        this.latinFamilyName = latinFamilyName;
    }

    public String getOrigin() {
        return origin;
    }

    public void setOrigin(String origin) {
        this.origin = origin;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public int getQty() {
        return qty;
    }

    public void setQty(int qty) {
        this.qty = qty;
    }
}
