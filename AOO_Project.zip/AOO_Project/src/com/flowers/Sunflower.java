package com.flowers;

public class Sunflower extends Flower {

    private String seedColoration;
    private String stalkCategory;

    public Sunflower(String id, String name, String origin, double price, int qty, String seedColoration, String stalkCategory) {
        super(id, name, origin, price, qty);

        setSeedColoration(seedColoration);
        setStalkCategory(stalkCategory);

        setLatinFamilyName("Helianthus");
    }

    public String getSeedColoration() {
        return seedColoration;
    }

    public void setSeedColoration(String seedColoration) {
        // applying business logic to ensure seed color is proper
        switch(seedColoration.toLowerCase()) {
            case "white":
            case "black":
            case "striped":
            case "autumn":
                this.seedColoration = seedColoration.toLowerCase();
                break;
            default:
                this.seedColoration = "unknown";
        }
    }

    public String getStalkCategory() {
        return stalkCategory;
    }

    public void setStalkCategory(String stalkCategory) {
        // apply business logic to ensure stalk category is proper
        switch(stalkCategory.toLowerCase()) {
            case "dwarf":
            case "medium":
            case "tall":
                this.stalkCategory = stalkCategory.toLowerCase();
                break;
            default:
                this.stalkCategory = "unknown";
        }
    }
}
