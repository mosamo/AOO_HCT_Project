package com.flowers;

import com.interfaces.IMedicinal;

public class Hibiscus extends Flower implements IMedicinal {

    private float pistilLength;

    public Hibiscus(String id, String name, String origin, double price, int qty, float pistilLength) {
        super(id ,name, origin, price, qty);

        setPistilLength(pistilLength);

        setLatinFamilyName("Malvoideae");
    }

    public float getPistilLength() {
        return pistilLength;
    }

    public void setPistilLength(float pistilLength) {
        this.pistilLength = pistilLength;
    }

    @Override
    public boolean isEdible() { // acquired from the IMedicinal Interface
        // Hibiscus is Edible
        return true;
    }

    @Override
    public String getUsageInstructions() { // acquired from the IMedicinal Interface
        return "Most Hibiscus plants can be boiled and drank for their medicinal properties";
    }

    @Override
    public String getUsageWarning() { // acquired from the IMedicinal Interface
        return "Warning: some types of Hibiscus can be poisonous to animals";
    }
}
