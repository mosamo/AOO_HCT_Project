package com.flowers;

import com.interfaces.IAromatic;

public class Lily extends Flower implements IAromatic {

    // some lily flowers are aquatic.
    private boolean aquatic;

    public Lily(String id, String name, String origin, double price, int qty, boolean aquatic) {
        super(id, name, origin, price, qty);

        setAquatic(aquatic);

        setLatinFamilyName("Lilioideae");
    }

    public boolean isAquatic() {
        return aquatic;
    }

    public void setAquatic(boolean aquatic) {
        this.aquatic = aquatic;
    }

    @Override
    public String getScentClassification() { // acquired from the IAromatic Interface
        return IAromatic.CLASS_III;
    }

    @Override
    public String getScentDescription() { // acquired from the IAromatic Interface
        return getName() + " tends to have a fresh, floral, uplifting smell\n" +
                            "Scent Grade: " + getScentClassification();
    }
}
