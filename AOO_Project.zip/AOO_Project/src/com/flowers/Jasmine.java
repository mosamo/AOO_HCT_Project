package com.flowers;

import com.interfaces.IAromatic;

public class Jasmine extends Flower implements IAromatic {

    private String petalArrangement;
    private boolean yellowTint;

    public Jasmine(String id, String name, String origin, double price, int qty, String petalArrangement, boolean yellowTint) {
        super(id, name, origin, price, qty);

        setPetalArrangement(petalArrangement);
        setYellowTint(yellowTint);

        setLatinFamilyName("Jasminaceae");
    }

    public String getPetalArrangement() {
        return petalArrangement;
    }

    public void setPetalArrangement(String petalArrangement) {
        // apply business logic to ensure arrangement type is correct
        switch(petalArrangement.toLowerCase()) {
            case "layered":
            case "pinwheel":
            case "spokes":
                this.petalArrangement = petalArrangement.toLowerCase();
                break;
            default:
                this.petalArrangement = "unknown";
        }
    }

    public boolean hasYellowTint() {
        return yellowTint;
    }

    public void setYellowTint(boolean yellowTint) {
        this.yellowTint = yellowTint;
    }

    @Override
    public String getScentClassification() { // acquired from the IAromatic Interface
        return IAromatic.CLASS_II;
    }

    @Override
    public String getScentDescription() { // acquired from the IAromatic Interface
        return getName() + " tends to have a floral and sensual scent, it is both relaxing and soothing\n" +
                            "Scent Grade: " + getScentClassification();
    }
}
