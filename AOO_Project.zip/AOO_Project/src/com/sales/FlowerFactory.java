package com.sales;

import com.flowers.*;

public class FlowerFactory {
    public static Flower createFlowerByType(String type, String id, String name, String origin, double price, int qty) {
        switch (type) {
            // no need for 'break;' since 'return;' ends it
            case "Lilioideae":
                return new Lily(id, name, origin, price, qty, false);
            case "Malvoideae":
                return new Hibiscus(id, name, origin, price, qty, 1.2f);
            case "Jasminaceae":
                return new Jasmine(id, name, origin, price, qty, "pinwheel", false);
            case "Magnoliaceae":
                return new Magnolia(id, name, origin, price, qty, true, true);
            case "Helianthus":
                return new Sunflower(id, name, origin, price, qty,"striped", "medium");
        }
        return null;
    }
}
