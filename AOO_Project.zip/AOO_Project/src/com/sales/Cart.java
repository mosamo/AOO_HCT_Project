package com.sales;

import com.DB.Flower;

import java.util.ArrayList;

public class Cart {
    private static Cart instance = null;
    private ArrayList<Flower> flowers = new ArrayList<>();
    private ArrayList<Bouquet> bouquets = new ArrayList<>();

    public static Cart getInstance() {
        if (instance == null) {
            instance = new Cart();
        }
        return instance;
    }

    public void add(Flower f) {
        flowers.add(f);
    }
    public void add(Bouquet b) {bouquets.add(b); }

    private Cart() {

    }

    public ArrayList<Flower> getFlowerList() {
        return flowers;
    }
    public ArrayList<Bouquet> getBouquets() {return bouquets; }

    public void calculateFlowerTotal() {
        double d = 0;
        for (Flower f : flowers) {
            d = d + f.getPrice();
        }
        System.out.println("Total Flowers Price is: " + d + " AED");
    }

    public void calculateBoquetTotal() {
        double d = 0;
        for (Bouquet b : bouquets) {
            d = d + b.getBouquetTotalPrice();
        }
        System.out.println("Total Bouquet Price is: " + d + " AED");
    }

}
