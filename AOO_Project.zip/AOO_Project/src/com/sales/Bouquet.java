package com.sales;

import com.flowers.Flower;
import com.flowers.Hibiscus;
import com.flowers.Lily;

public class Bouquet<T> {
    private T flower;

    private double basePrice;
    private final double BOUQUET_PRICE = 25.0;

    public Bouquet(T obj) {
        // if the object is a child of a flower
        // it has flower methods
        if (obj instanceof Flower) {
            flower = obj;
            basePrice = ((Flower) obj).getPrice();
        }
    }

    public double getBouquetTotalPrice() {
        return basePrice + BOUQUET_PRICE;
    }

    public String getBouquetDescription() {
        return "A Bouquet of " + ((Flower) flower).getQty() + " " + ((Flower) flower).getName();
    }


}
